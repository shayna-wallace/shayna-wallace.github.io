import java.time.LocalDate;

public class AppointmentService {
	
	public static void addAppointment(String appointmentID, LocalDate appointmentDate, String Description) {
	}

	public static void deleteAppointment (String appointmentID, LocalDate appointmentDate, String Description) {
	}
	
	}

