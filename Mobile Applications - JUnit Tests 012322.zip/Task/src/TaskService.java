/**
 * This program was created for a mobile application and to test the requirements for the 
 * to make sure all the requirements have been meet and passes.
 * This class houses the requirements for the task services and makes sure that tasks
 * can add, deleted, and updated.
**/

//For the any task the customer creates, we want them to be able to add new tasks, update the task,
//and delete the task

public class TaskService {
	
	
	
	 public static void addTask(String taskID,String Name, String Description) {
         }

	 public static void deleteTask(String taskID,String Name, String Description) {
		 } 
	 
	 public static void updateTask(String taskID,String Name, String Description) {
		 }

	



}
